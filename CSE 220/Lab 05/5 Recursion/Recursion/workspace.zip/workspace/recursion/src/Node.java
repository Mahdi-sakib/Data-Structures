
public class Node {
	Object element;
	Node next;
	
	public Node(Object elem,Node n){
		element=elem;
		next=n;
	}
}
